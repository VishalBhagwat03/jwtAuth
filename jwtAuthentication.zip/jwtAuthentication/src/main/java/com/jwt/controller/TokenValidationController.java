package com.jwt.controller;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

@RestController
@RequestMapping("/api")
public class TokenValidationController {

    private static final String SECRET_KEY = "Vishal_bhagwat";
    private static final long EXPIRATION_TIME = 86400000; 

    @GetMapping("/validate-token")
    public ResponseEntity<String> validateToken(@RequestHeader("Session-Token") String sessionToken) {

        String accessToken = generateAccessToken();

        return ResponseEntity.ok(accessToken);
    }

    private String generateAccessToken() {
        Date now = new Date();
        Date expiration = new Date(now.getTime() + EXPIRATION_TIME);

        String accessToken = Jwts.builder()
                .setIssuedAt(now)
                .setExpiration(expiration)
                .signWith(SignatureAlgorithm.HS256, SECRET_KEY)
                .compact();

        return accessToken;
    }
}